//
//  ViewController.swift
//  JCPageView
//
//  Created by 严伟 on 2018/5/15.
//  Copyright © 2018年 yW. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let rect = CGRect(x: 0, y: 64, width: Constant.screenWidth, height: Constant.screenHeight - 64)
        let pageView = JCPageView(frame: rect, ["个人工单", "小组工单"], font: Font.dp(20))
        pageView.setTitle(height: 48)
        pageView.delegate = self
        view.addSubview(pageView)
        
        let bigView = UIView()
        bigView.backgroundColor = .red
        bigView.frame = CGRect(x: 100, y: 100, width: 100, height: 100)
        pageView.set(bigView, index: 1)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

extension ViewController: JCPageViewDelegate {
    func selectedItem(index: Int) {
        
    }
}

